package api;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {

        RacingAPI raceData = new RacingAPI("drivers");
        raceData.makeConnection();

    }
}

