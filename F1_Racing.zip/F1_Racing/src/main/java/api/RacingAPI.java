package api;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.ws.rs.HttpMethod;

public class RacingAPI {
    private String urlString = "http://ergast.com/api/f1/";
    private final int timeOut = 1000;

    private HttpURLConnection connection = null;
    private String Jsonobj;



    public RacingAPI(String Jsonobj) {
        this.Jsonobj = Jsonobj;

    }

    public void makeConnection() {
        try {

            this.urlString += this.Jsonobj + ".json";
            urlString += "?&limit=50";
            System.out.println(urlString);
            final URL url = new URL(urlString);
            getResponse(url);
            System.out.println(connection.getResponseCode());

            if (connection.getResponseCode() == 200) {
                final InputStream inputStream = connection.getInputStream();
                final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

                //System.out.println(bufferedReader.readLine());
              JSONParser parser = new JSONParser();
              JSONObject response = (JSONObject) parser.parse(bufferedReader.readLine());

                String tofile= "";
                System.out.println("Printing Data");
                JSONObject resp_obj = (JSONObject) response.get("MRData");
                JSONObject raceData = (JSONObject) resp_obj.get("DriverTable");
                JSONArray results = (JSONArray) raceData.get("Drivers");

                WriterAppF1race wr = new WriterAppF1race();
                String path = wr.setPath();
                RandomWriterF1race rw = new RandomWriterF1race(path,"Driver.txt");

                for (Object r: results)
                {

                    JSONObject result = (JSONObject) r;
                    tofile = "The Driver Named  " +result.get("givenName")+ " Nationality is " +result.get("nationality") +"\n";
                    System.out.println(tofile);
                    rw.Writedata(tofile);

                }

            }
                } catch (Exception e) {
                    System.out.println(e.toString());
                }

            }

            private void getResponse(URL url) throws IOException
            {
                connection = (HttpURLConnection) url.openConnection();
                connection.setConnectTimeout(timeOut);
                connection.setRequestMethod(HttpMethod.GET);
            }
        }